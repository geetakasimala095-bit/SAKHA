const express=require("express");
const multer=require("multer");
const fs=require("fs");
const os=require("os");
const path=require("path");

const app=express();
const upload=multer({dest:path.join(os.tmpdir(),"sakha-uploads"),limits:{fileSize:1024*1024*1024}});
const PORT=process.env.PORT||3000;
const API=process.env.META_API_VERSION||"v25.0";
const TOKEN=process.env.META_ACCESS_TOKEN||"";
const IG_ID=process.env.INSTAGRAM_USER_ID||"";
const PAGE_ID=process.env.FACEBOOK_PAGE_ID||"";

app.use(express.static(__dirname));

async function graphPost(endpoint,body){
 const r=await fetch(`https://graph.facebook.com/${API}${endpoint}`,{
  method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
  body:new URLSearchParams(body)
 });
 const d=await r.json();
 if(!r.ok||d.error) throw new Error(d.error?.message||`Meta API error ${r.status}`);
 return d;
}

async function publishInstagram(videoUrl,caption){
 const c=await graphPost(`/${IG_ID}/media`,{
  media_type:"REELS",video_url:videoUrl,caption,share_to_feed:"true",access_token:TOKEN
 });
 if(!c.id) throw new Error("Instagram container ID missing.");
 for(let i=0;i<36;i++){
  const r=await fetch(`https://graph.facebook.com/${API}/${c.id}?fields=status_code,status&access_token=${encodeURIComponent(TOKEN)}`);
  const s=await r.json();
  if(s.status_code==="FINISHED") break;
  if(["ERROR","EXPIRED"].includes(s.status_code)) throw new Error(s.status||s.status_code);
  await new Promise(x=>setTimeout(x,5000));
 }
 return graphPost(`/${IG_ID}/media_publish`,{creation_id:c.id,access_token:TOKEN});
}

async function publishFacebook(videoPath,caption){
 const start=await graphPost(`/${PAGE_ID}/video_reels`,{upload_phase:"start",access_token:TOKEN});
 if(!start.video_id||!start.upload_url) throw new Error("Facebook upload session missing.");
 const buf=fs.readFileSync(videoPath);
 const up=await fetch(start.upload_url,{
  method:"POST",
  headers:{"Authorization":`OAuth ${TOKEN}`,"offset":"0","file_size":String(buf.length),"Content-Type":"application/octet-stream"},
  body:buf
 });
 const ud=await up.json().catch(()=>({}));
 if(!up.ok||ud.success===false) throw new Error(ud.error?.message||"Facebook upload failed.");
 return graphPost(`/${PAGE_ID}/video_reels`,{
  upload_phase:"finish",video_id:start.video_id,video_state:"PUBLISHED",description:caption,access_token:TOKEN
 });
}

app.post("/api/social/publish",upload.single("video"),async(req,res)=>{
 if(!req.file)return res.status(400).json({success:false,message:"Video file missing."});
 const platform=req.body.platform||"instagram",caption=req.body.caption||"";
 try{
  if(!TOKEN)throw new Error("META_ACCESS_TOKEN is not configured.");
  if(platform==="facebook"){
   const result=await publishFacebook(req.file.path,caption);
   return res.json({success:true,message:"✅ Facebook Reel published.",result});
  }
  if(platform==="instagram"||platform==="both"){
   return res.status(501).json({success:false,message:"Instagram API is ready, but the video must first be uploaded to public HTTPS storage (S3/Cloudinary/Supabase)."});
  }
  return res.status(400).json({success:false,message:"Invalid platform."});
 }catch(e){console.error(e);res.status(500).json({success:false,message:e.message});}
 finally{try{fs.unlinkSync(req.file.path)}catch{}}
});

app.listen(PORT,()=>console.log(`SAKHA running: http://localhost:${PORT}`));
