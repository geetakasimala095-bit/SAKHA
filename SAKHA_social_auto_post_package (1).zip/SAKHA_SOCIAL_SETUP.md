# SAKHA Social Auto-Post
1. `npm install`
2. Put Meta credentials in environment variables; NEVER put tokens in index.html.
3. `npm start`
4. Open `http://localhost:3000`.

Facebook Page Reel publishing uses Meta's start -> upload -> finish flow.
Instagram Reels use a media container -> processing status -> media_publish flow.
For Instagram, Meta requires the video to be reachable through a public HTTPS URL, so connect S3/Cloudinary/Supabase Storage before enabling production Instagram auto-post.

Verify current Meta permissions, account eligibility and API requirements before production.
